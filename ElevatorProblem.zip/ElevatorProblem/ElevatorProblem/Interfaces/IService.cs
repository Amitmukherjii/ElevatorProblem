﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace ElevatorProblem
{
    public interface IService
    {
        Task<int> GetRandomData();
        Task<IList<int>> GetUserRequestList();
        Task<int> GetUserRequest();
        void RemoveUserRequest(int value);

    }
}