﻿namespace ElevatorProblem
{
    public interface IElevatorController
    {
        void UpdateElevatorQueue(Elevator elevator);
        void CalculateNextFloor(Elevator elevator);
    }
}