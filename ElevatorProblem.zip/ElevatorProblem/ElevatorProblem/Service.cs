﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ServiceReference1;

namespace ElevatorProblem
{
    public class Service: IService
    {
       Service1Client service = new Service1Client();

        public async Task<int> GetRandomData()
        {
            return await service.GetRandomDataAsync();
        }

        public async Task<IList<int>> GetUserRequestList()
        {
            return await service.GetUserRequestListAsync();
        }

        public async Task<int> GetUserRequest()
        {
            return await service.GetUserRequestAsync();
        }

        public async void RemoveUserRequest(int value)
        {
            await service.RemoveUserRequestAsync(value);
        }
    }
}
