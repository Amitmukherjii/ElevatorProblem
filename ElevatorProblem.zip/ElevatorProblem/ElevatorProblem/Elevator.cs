﻿
namespace ElevatorProblem
{
    public class Elevator:ElevatorStatus
    {
        public string Name { get; set; }
    }
}
