﻿using NUnit.Framework;
using ElevatorProblem;
using System.Collections.Generic;

namespace ElevatorProblemTest
{
    public class ElevatorLogicsTest
    {
        Elevator e = new Elevator();
        private ElevatorLogics logic = null;
        [SetUp]
        public void Setup()
        {
            logic = new ElevatorLogics();
           
        }

        [Test]
        public void Should_Get_Minimum_Number_FromQueue()
        {
            e.ElevatorDirection = Direction.UP;
            e.RequestQueue = new List<int>() { 1, 2, 3 };
           
            var elevatorList = logic.GetPriorityFloorFromQueue(e,3);
            Assert.AreEqual(1,1);
        }

        [Test]
        public void Should_Get_Maximum_Number_FromQueue()
        {
            e.ElevatorDirection = Direction.DOWN;
            e.RequestQueue = new List<int>() { 1, 2, 3 };

            var elevatorList = logic.GetPriorityFloorFromQueue(e, 3);
            Assert.AreEqual(3, 3);
        }
    }
}
