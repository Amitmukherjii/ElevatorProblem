using NUnit.Framework;
using ElevatorProblem;
namespace Tests
{
    public class ElevatorFactoryTest
    {
        private ElevatorFactory factory = null;
        [SetUp]
        public void Setup()
        {
            factory = new ElevatorFactory();
        }

        [Test]
        public void Should_Create_3_Elevator_With_Request_For_3()
        {
            var elevatorList = factory.GetElevators(3);
            Assert.AreEqual(elevatorList.Count, 3);
        }
    }
}