﻿using ElevatorProblem;
using System.Collections.Generic;

namespace ElevatorUI
{
    public interface ISelectElevator
    {
        int NearestElevator(IList<Elevator> elevators, int destinationFloor);
    }
}