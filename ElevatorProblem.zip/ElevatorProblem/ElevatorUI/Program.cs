﻿using ElevatorProblem;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Unity;

namespace ElevatorUI
{
    class Program
    {
        static void Main(string[] args)
        {
            var container = new UnityContainer();
            container.RegisterType<ISelectElevator, SelectElevatorAmongThree>();
            container.RegisterType<IElevatorFactory, ElevatorFactory>();
            container.RegisterType<IElevatorLogics, ElevatorLogics>();
            container.RegisterType<IElevatorController, ElevatorController>();
            container.RegisterType<IService, Service>();

            var factory = container.Resolve < IElevatorFactory>();
            //var logic = container.Resolve<IElevatorLogics>();
            var controller = container.Resolve < IElevatorController>();
            var elevator = container.Resolve<ISelectElevator>();
            var service = container.Resolve<IService>();

            const int No_Of_Elevators = 3;
            int selected = 0;
            int destinationFloor = 0;

            IList<Elevator> elevators = factory.GetElevators(No_Of_Elevators);
           
            do
            {
                destinationFloor = service.GetUserRequest().Result;
               if (destinationFloor != -10)
                {
                    selected = elevator.NearestElevator( elevators, destinationFloor);
                    elevators[selected].FinalDestination = destinationFloor;
                    controller.UpdateElevatorQueue(elevators[selected]);

                    Task t = Task.Factory.StartNew(() =>
                    {
                        controller.CalculateNextFloor(elevators[selected]);
                    });
                }
            } while (true);
        }

    }
}
