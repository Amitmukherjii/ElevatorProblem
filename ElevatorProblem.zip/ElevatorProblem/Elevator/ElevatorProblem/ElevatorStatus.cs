﻿using System.Collections.Generic;

namespace ElevatorProblem
{
    public abstract class ElevatorStatus
    {
        //private int currentFloor;
        //private  ;
        //private int finalDestination;

         public int CurrentFloor { get; set; }
         public int FinalDestination { get; set; }
         public Direction ElevatorDirection { get; set; }
         public IList<int> RequestQueue { get; set; }

    }
}
