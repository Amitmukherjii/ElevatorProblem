﻿using System;

namespace ElevatorProblem
{
    public class Request
    {
        private int floor;
        private Direction direction;
        private DateTime requestTime;
    }
}
