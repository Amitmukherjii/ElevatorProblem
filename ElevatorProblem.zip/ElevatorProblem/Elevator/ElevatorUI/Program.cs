﻿using ElevatorProblem;
using System;
using System.Collections.Generic;
using System.Threading;

namespace ElevatorUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int noOfElevators = 1;
                     
            IList < Elevator > elevators = new List<Elevator>();

            for (int i = 0; i < noOfElevators; i++)
            {
                elevators.Add(
                    new Elevator
                    {
                        Name = "Elevator "+i+1,
                        CurrentFloor = 0,
                        ElevatorDirection = Direction.HAULT,
                        FinalDestination = 0,
                        RequestQueue = new List<int> { 0}
                    });
            }

           int destinationFloor = 0;
            do
            {
                Console.WriteLine("Enter Destination Floor");
                destinationFloor = Convert.ToInt16(Console.ReadLine());

                UpdateElevatorQueue(destinationFloor, elevators);
                NearestElevator(elevators);
            } while (destinationFloor != 111);


            
        }

        private static void UpdateElevatorQueue(int destinationFloor, IList<Elevator> elevators)
        {
            elevators[0].RequestQueue.Clear();
            elevators[0].RequestQueue.Add(destinationFloor);
            elevators[0].RequestQueue.Add(3);
            elevators[0].RequestQueue.Add(9);
        }

        private static void NearestElevator( IList<Elevator> elevators)
        {
            foreach (var destinationFloor in elevators[0].RequestQueue)
            {
                
                if (destinationFloor > elevators[0].CurrentFloor)
                {
                    for (int i = elevators[0].CurrentFloor; i < elevators[0].RequestQueue[0]; i++)
                    {
                        Thread.Sleep(1000);
                        elevators[0].ElevatorDirection = Direction.UP;
                        elevators[0].CurrentFloor = i;
                        Console.WriteLine(elevators[0].Name + " at " + (i) + " Floor, Elevator moving " + elevators[0].ElevatorDirection);
                    }
                }
                else
                {
                    for (int i = elevators[0].CurrentFloor; i > destinationFloor; i--)
                    {
                        Thread.Sleep(1000);
                        elevators[0].ElevatorDirection = Direction.DOWN;
                        elevators[0].CurrentFloor = i;
                        Console.WriteLine(elevators[0].Name + " at " + (i) + " Floor, Elevator moving " + elevators[0].ElevatorDirection);
                    }
                }

                elevators[0].ElevatorDirection = Direction.HAULT;
                Console.WriteLine(elevators[0].Name + " arrived at " + destinationFloor + " Floor, Elevator moving " + elevators[0].ElevatorDirection);
                elevators[0].CurrentFloor = destinationFloor;
            }
        }

   
    }
}
