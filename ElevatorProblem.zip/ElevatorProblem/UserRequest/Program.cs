﻿using System;
using ServiceReference1;

namespace UserRequest
{
    class Program
    {
        private const int MINIMUM = -2;
        private const int MAXIMUM = 10;

        static void Main(string[] args)
        {
            Service1Client service = new Service1Client();
            do
            {
                Console.WriteLine("Enter Floor Request Here: -2 to 10");
                Int32.TryParse(Console.ReadLine(), out int floor);
                if (floor>= MINIMUM && floor <= MAXIMUM)
                {
                    service.UpdateUserRequestAsync(floor);
                }
                
            } while (true);
        }
    }
}
