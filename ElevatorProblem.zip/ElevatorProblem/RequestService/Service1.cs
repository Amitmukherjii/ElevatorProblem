﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

namespace RequestService
{
    [ServiceBehavior(InstanceContextMode =InstanceContextMode.Single, ConcurrencyMode =ConcurrencyMode.Multiple)]
    public class Service1 : IService1
    {
        IList<int> userRequestList = new List<int>();
        Random random = new Random();
        int newUserRequest = 0;
        public int GetRandomData()
        {
            return random.Next(-2, 10);
        }

        public void UpdateUserRequestList(int value)
        {
            userRequestList.Add(value);
        }

        public IList<int> GetUserRequestList()
        {
            return userRequestList;
        }

        public int GetUserRequest()
        {
            int temp = newUserRequest;
            newUserRequest = -10;
            return temp;
        }

        public void UpdateUserRequest(int value)
        {
            newUserRequest=value;
        }

        public void RemoveUserRequest(int value)
        {
            userRequestList.Remove(value);
        }

    }
}
