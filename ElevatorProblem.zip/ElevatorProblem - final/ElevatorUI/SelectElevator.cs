﻿using ElevatorProblem;
using System;
using System.Collections.Generic;
using System.Text;

namespace ElevatorUI
{
    public class SelectElevatorAmongThree : ISelectElevator
    {
        public int NearestElevator(IList<Elevator> elevators, int destinationFloor)
        {
            int e1Floor = Math.Abs(elevators[0].CurrentFloor - destinationFloor);
            int e2Floor = Math.Abs(elevators[1].CurrentFloor - destinationFloor);
            int e3Floor = Math.Abs(elevators[2].CurrentFloor - destinationFloor);

           if (e1Floor < e2Floor)
            {
                if (e1Floor < e3Floor)
                {
                    return 0;
                }
                else
                {
                    return 2;
                }
            }
            else if (e2Floor < e3Floor)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }

    }
}
