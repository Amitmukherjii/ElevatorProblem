﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElevatorProblem
{
    public class Elevator:ElevatorStatus
    {
        public string Name { get; set; }
        
        public virtual bool HaultAt(int floor)
        {
            return false;
        }
    }
}
