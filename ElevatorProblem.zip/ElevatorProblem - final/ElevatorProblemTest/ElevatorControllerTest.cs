﻿using NUnit.Framework;
using ElevatorProblem;

namespace ElevatorProblemTest
{
    public class ElevatorControllerTest
    {
        //private ElevatorController controller = null;
        //[SetUp]
        //public void Setup()
        //{
        //    controller = new ElevatorController();
        //}

        //[Test]
        //public void Should_Create_3_Elevator_With_Request_For_3()
        //{
        //    var elevatorList = controller.UpdateElevatorQueue(3);
        //    Assert.AreEqual(elevatorList.Count, 3);
        //}
    }
}
