﻿using System;
using ServiceReference1;

namespace UserRequest
{
    class Program
    {
        private const int MINIMUM = -2;
        private const int MAXIMUM = 10;

        static void Main(string[] args)
        {
            int floor;
            Service1Client service = new Service1Client();
            do
            {
                Console.WriteLine("Enter Floor Request Here: -2 to 10");
                floor = Convert.ToInt16(Console.ReadLine());
                if (floor>= MINIMUM && floor <= MAXIMUM)
                {
                    service.UpdateUserRequestAsync(floor);
                }
                
            } while (true);
        }
    }
}
