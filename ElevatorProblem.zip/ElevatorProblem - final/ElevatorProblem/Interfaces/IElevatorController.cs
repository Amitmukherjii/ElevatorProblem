﻿namespace ElevatorProblem
{
    public interface IElevatorController
    {
        void UpdateElevatorQueue(int destinationFloor, Elevator elevator);
        void CalculateNextFloor(int destinationFloor, Elevator elevator);
    }
}