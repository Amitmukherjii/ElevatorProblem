﻿using System.Collections.Generic;

namespace ElevatorProblem
{
    public interface IElevatorFactory
    {
        IList<Elevator> GetElevators(int noOfElevators);
    }
}