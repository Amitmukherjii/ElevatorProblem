﻿namespace ElevatorProblem
{
    public interface IElevatorLogics
    {
        int GetPriorityFloorFromQueue(Elevator elevator, int currentFloor);
        void MoveElevator(Elevator elevator, int currentFloor, Direction direction);
        int CheckAndSetNewFloorRequest(Elevator elevator, int priorityFloor);
    }
}