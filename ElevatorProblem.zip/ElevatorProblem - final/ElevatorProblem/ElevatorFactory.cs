﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElevatorProblem
{
    public class ElevatorFactory : IElevatorFactory
    {
        public IList<Elevator> GetElevators(int noOfElevators)
        {
            IList<Elevator> elevators = new List<Elevator>();

            for (int i = 0; i < noOfElevators; i++)
            {
                elevators.Add(
                    new Elevator
                    {
                        Name = "Elevator " + (i+1),
                        CurrentFloor = 0,
                        ElevatorDirection = Direction.UP,
                        FinalDestination = 0,
                        RequestQueue = new List<int> ()
                    });
            }
            return elevators;
        }
    }
}
