﻿using System;
using System.Linq;
using System.Threading;

namespace ElevatorProblem
{
    public class ElevatorLogics: IElevatorLogics
    {
        //private IService _service;
        //public ElevatorLogics(IService service)
        //{
        //    _service = service;
        //}
        Service _service = new Service();
        public int GetPriorityFloorFromQueue(Elevator elevator, int currentFloor)
        {
            return (elevator.ElevatorDirection == Direction.UP)
                ? elevator.RequestQueue.Min()
                : elevator.RequestQueue.Max();

            #region MyRegion
            //if (elevators[0].ElevatorDirection == Direction.UP && (elevators[0].RequestQueue.Min() > currentFloor))
            //{
            //    return elevators[0].RequestQueue.Min();
            //}
            //else if (elevators[0].ElevatorDirection == Direction.DOWN && (elevators[0].RequestQueue.Max() < currentFloor))
            //{
            //    return elevators[0].RequestQueue.Max();
            //}
            //return originalDestination; 
            #endregion
        }

        public void MoveElevator(Elevator elevator, int currentFloor, Direction direction)
        {
            Thread.Sleep(2000);
            elevator.ElevatorDirection = direction;
            elevator.CurrentFloor = currentFloor;
            Console.WriteLine("{0} at {1} Floor, Elevator moving {2}", elevator.Name, elevator.CurrentFloor, elevator.ElevatorDirection);
        }

        public int CheckAndSetNewFloorRequest(Elevator elevator, int priorityFloor)
        {
            int newFloor = _service.GetUserRequest().Result;
            if (newFloor != -10)
            {
                //priorityFloor = CheckForPriorityFloor(elevator, newReq, priorityFloor);
                if (!elevator.RequestQueue.Contains(newFloor))
                {
                    elevator.RequestQueue.Add(newFloor);
                    Console.WriteLine("New floor requested is {0} \n", newFloor);
                }
                if (elevator.ElevatorDirection == Direction.UP && (elevator.RequestQueue.Min() > elevator.CurrentFloor))
                {
                    priorityFloor = elevator.RequestQueue.Min();
                }
                else if (elevator.ElevatorDirection == Direction.DOWN && (elevator.RequestQueue.Max() < elevator.CurrentFloor))
                {
                    priorityFloor = elevator.RequestQueue.Max();
                }
            }
            return priorityFloor;
        }
    }
}
