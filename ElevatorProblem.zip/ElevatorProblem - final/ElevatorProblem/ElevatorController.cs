﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;



namespace ElevatorProblem
{
    public class ElevatorController : IElevatorController
    {
        //private IElevatorLogics _elevatorLogics;

        //public ElevatorController(IElevatorLogics elevatorLogics)
        //{
        //    _elevatorLogics = elevatorLogics;
        //}
        ElevatorLogics _elevatorLogics = new ElevatorLogics();
        public  void UpdateElevatorQueue(int destinationFloor, Elevator elevator)
        {
            if (!elevator.RequestQueue.Contains(destinationFloor))
            {
                Console.WriteLine("New floor requested is {0} \n", destinationFloor);
                elevator.RequestQueue.Add(destinationFloor);
            }
        }

        public void CalculateNextFloor(int destinationFloor, Elevator elevator)
        {
            int priorityFloor = destinationFloor;
            for (int index = 0; index < elevator.RequestQueue.ToList().Count; index++)
            {
                priorityFloor = _elevatorLogics.GetPriorityFloorFromQueue(elevator, elevator.CurrentFloor);
                priorityFloor = CalculatePriorityFloor(elevator, priorityFloor);

                elevator.CurrentFloor = priorityFloor;
                elevator.RequestQueue.Remove(priorityFloor);
                Console.WriteLine("{0} arrived at {1} Floor, Elevator Haulted at {2}", elevator.Name, priorityFloor, elevator.CurrentFloor);

                if (elevator.RequestQueue.Any())
                    index--;
                else break;

            }
        }

        private int CalculatePriorityFloor(Elevator elevator, int priorityFloor)
        {
            if (priorityFloor > elevator.CurrentFloor)
            {
                for (int i = elevator.CurrentFloor; i < priorityFloor; i++)
                {
                    _elevatorLogics.MoveElevator(elevator, i, Direction.UP);
                    priorityFloor = _elevatorLogics.CheckAndSetNewFloorRequest(elevator, priorityFloor);
                }
            }
            else
            {
                for (int i = elevator.CurrentFloor; i > priorityFloor; i--)
                {
                    _elevatorLogics.MoveElevator(elevator, i, Direction.DOWN);
                    priorityFloor = _elevatorLogics.CheckAndSetNewFloorRequest(elevator, priorityFloor);
                }
            }

            return priorityFloor;
        }
    }
}
