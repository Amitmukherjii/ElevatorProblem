﻿namespace ElevatorProblem
{
    public enum Direction
    {
        UP,
        DOWN
    }
}