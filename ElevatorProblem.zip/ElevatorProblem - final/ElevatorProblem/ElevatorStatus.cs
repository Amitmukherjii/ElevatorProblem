﻿using System.Collections.Generic;

namespace ElevatorProblem
{
    public class ElevatorStatus
    {
         public int CurrentFloor { get; set; }
         public int FinalDestination { get; set; }
         public Direction ElevatorDirection { get; set; }
         public IList<int> RequestQueue { get; set; }
    }
}
